create schema second_auto;
 
 -- creazione tabella 1
 create table concessionario(
id_conc integer primary key not null,
città varchar(20),
indirizzo varchar(50),
telefono varchar(20),
responsabile varchar(30)
);

-- creazione tabella 2
create table regioni(
id_regione int primary key not null,
regione varchar(20),
città varchar(20),
id_conc int ,foreign key(id_conc) references concessionario(id_conc)
);

-- creazione tabella 3
create table auto(
targa integer primary key not null,
marca varchar(25),
colore varchar(15),
cilindrata integer,
cambio varchar(20),
prezzo double,
id_conc integer,
foreign key(id_conc) references concessionario(id_conc)
);

-- creazione tabella 4
create table proprietari(
id_proprietario integer primary key not null,
targa integer,
nominativo varchar(30),
città varchar(25),
anno_acq year ,
anno_ven year,
foreign key(targa) references auto(targa)
);

-- inserimento dei valori per tabella  
insert into proprietari(id_proprietario,targa,nominativo,città,anno_acq,anno_ven)
values(1, 1, 'Mario Rossi', 'Milano', 2012, 2014),
(2, 2, 'Laura Bianchi', 'Roma', 2019, 2023),
(3, 3, 'Luigi Verdi', 'Milano', 2017, 2019),
(4, 3, 'Anna Gialli', 'Milano', 2019, 2021),
(5, 5, 'Carlo Marroni', 'Milano', 2015, 2017),
(6, 3, 'Elena Neri',  'Palermo', 2021, 2022),
(7, 6, 'Giovanni Blu', 'Roma', 2012, 2014),
(8, 7, 'Francesca Rosa', 'Roma', 2012, 2015),
(9, 8, 'Marco Verde', 'Milano', 2012, 2014),
(10, 20, 'Paola Arancio', 'Milano', 2012, 2015),
(11, 34, 'Roberto Grigio', 'Brindisi', 2015, 2017),
(12, 35, 'Sara Viola', 'Torino',2015, 2017),
(13, 37, 'Antonio Marrone', 'Roma', 2015, 2017),
(14, 40, 'Cristina Azzurri', 'Torino', 2015, 2017),
(15, 44, 'Davide Bianchi', 'Torino', 2015, 2017),
(16, 45, 'Elisa Gialli', 'Torino', 2017, 2019),
(17, 46, 'Fabio Rossi', 'Roma', 2017, 2019),
(18, 50, 'Giulia Verdi', 'Milano', 2017, 2019),
(19, 55, 'Ivan Neri', 'Brindisi', 2017, 2019),
(20, 59, 'Linda Blu','Torino', 2017, 2019),
(21, 60, 'Massimo Marroni', 'Milano', 2017, 2019),
(22, 63, 'Elena Bianchi', 'Roma', 2017, 2019),
(40, 40, 'Linda Blu', 'Roma', 2017, 2019),
(41, 41, 'Massimo Marroni', 'Milano', 2017, 2019),
(42, 65, 'Elena Bianchi', 'Roma', 2012, 2016),
(43, 68, 'Andrea Verdi', 'Palermo', 2012, 2016),
(44, 70, 'Laura Gialli', 'Torino', 2012, 2016),
(45, 79, 'Roberto Marrone', 'Roma', 2012, 2016),
(46, 73, 'Maria Neri', 'Milano', 2017, 2019),
(47, 81, 'Giovanni Blu', 'Palermo', 2017, 2019),
(48, 84, 'Francesca Rosa','Torino', 2017, 2019),
(49, 86, 'Marco Verde','Roma', 2012, 2016),
(50, 90, 'Paola Arancio','Roma',2012, 2016),
(51, 93, 'Davide Grigio', 'Milano', 2012, 2016),
(52, 95, 'Sara Viola', 'Milano', 2012, 2016),
(53, 99, 'Antonio Marrone', 'Milano', 2020, 2022),
(54, 52, 'Cristina Azzurri', 'Milano', 2019, 2020),
(55, 61, 'Elisa Bianchi', 'Roma', 2015, 2018),
(56, 49, 'Fabio Gialli', 'Palermo', 2015, null),
(57, 27, 'Giulia Rossi', 'Palermo', 2015, 2018),
(58, 13, 'Ivan Verdi', 'Parma',2015, 2018),
(59, 88, 'Lorenzo Neri', 'Roma',2015, 2018),
(60, 83, 'Chiara Blu','Roma', 2012, 2015),
(61, 95, 'Marco Marroni', 'Milano', 2016, 2018),
(62, 61, 'Elena Bianchi', 'Roma', 2018, 2020),
(63, 44, 'Andrea Verdi','Brindisi', 2017, 2019),
(64, 33, 'Laura Gialli','Torino', 2016, 2018),
(65, 36, 'Roberto Marrone', 'Torino', 2017, 2019),
(66, 47, 'Maria Neri', 'Palermo', 2012, null),
(67, 8, 'Giovanni Blu', 'Palermo', 2014, 2015),
(68, 3, 'Francesca Rosa','Roma', 2022, 2023),
(69, 1, 'Marco Verde', 'Milano', 2014, 2018),
(70, 70, 'Paola Arancio', 'Palermo', 2016, 2021),
(23, 23, 'Andrea Verdi', 'Brindisi', 2012, 2016),
(24, 24, 'Laura Gialli', 'Palermo', 2021, 2022),
(25, 3, 'Roberto Marrone', 'Torino', 2023, 2024),
(26, 4, 'Maria Neri','Torino', 2012, 2016),
(27, 5, 'Giovanni Blu','Torino', 2017, 2019),
(28, 28, 'Francesca Rosa', 'Milano', 2012, 2016),
(29, 36, 'Marco Verde', 'Palermo', 2012, 2016),
(30, 88, 'Paola Arancio', 'Bari', 2018, 2020),
(31, 31, 'Davide Grigio','Roma', 2020, null),
(32, 24, 'Sara Viola','Roma', 2022, 2023),
(33, 33, 'Antonio Marrone', 'Brindisi', 2018, 2020),
(34, 88, 'Cristina Azzurri', 'Padova', 2020, 2022),
(35, 99, 'Elisa Bianchi', 'Palermo', 2022, 2024),
(36, 92, 'Fabio Gialli','Brindisi', 2020, 2022),
(37, 44, 'Giulia Rossi','Roma', 2022, 2023),
(38, 16, 'Ivan Verdi','Torino', 2018, 2021);

insert into regioni(id_regione,regione,città,id_conc)
values
    (1, 'Lombardia', 'Milano',2),
    (2, 'Piemonte', 'Torino',3),
    (3,'Lazio','Roma',1),
    (4,'Sicilia','Palermo',4),
    (5,'Puglia','Brindisi',5);

INSERT INTO auto (targa, marca, colore, cilindrata, cambio, prezzo, id_conc) VALUES
('01', 'Fiat', 'Rosso', 1400, 'Manuale', 12000, 3),
('02', 'Honda', 'Blu', 2000, 'Automatico', 18000, 3),
('03', 'Ford', 'Nero', 1600, 'Manuale', 15000, 3),
('04', 'Fiat', 'Grigio', 1800, 'Automatico', 17000, 3),
('05', 'Honda', 'Verde', 1300, 'Manuale', 11000, 3),
('06', 'Ford', 'Bianco', 2500, 'Automatico', 22000, 3),
('07', 'Mercedes', 'Argento', 2200, 'Automatico', 20000, 3),
('08', 'Mercedes', 'Giallo', 1900, 'Manuale', 16000, 3),
('09', 'Fiat', 'Arancione', 1500, 'Manuale', 13000, 3),
('10', 'Honda', 'Viola', 1700, 'Automatico', 14000, 3),
('11', 'Ford', 'Nero', 1400, 'Manuale', 12500, 3),
('12', 'Mercedes', 'Blu', 1600, 'Automatico', 15500, 3),
('13', 'Fiat', 'Rosso', 1800, 'Manuale', 16500, 3),
('14', 'Honda', 'Grigio', 2000, 'Automatico', 18500, 3),
('15', 'Ford', 'Nero', 1900, 'Manuale', 17000, 3),
('16', 'Mercedes', 'Argento', 1500, 'Manuale', 13500, 3),
('17', 'Fiat', 'Arancione', 1300, 'Automatico', 12000, 3),
('18', 'Fiat', 'Viola', 1700, 'Manuale', 14500, 3),
('19', 'Fiat', 'Bianco', 1400, 'Automatico', 13000, 3),
('20', 'Honda', 'Nero', 2000, 'Manuale', 17500, 3),
('21', 'Fiat', 'Rosso', 1400, 'Manuale', 12000, 4),
('22', 'Honda', 'Blu', 2000, 'Automatico', 18000, 4),
('23', 'Ford', 'Nero', 1600, 'Manuale', 15000, 4),
('24', 'Fiat', 'Grigio', 1800, 'Automatico', 17000, 4),
('25', 'Honda', 'Verde', 1300, 'Manuale', 11000, 4),
('26', 'Ford', 'Bianco', 2500, 'Automatico', 22000, 4),
('27', 'Mercedes', 'Argento', 2200, 'Automatico', 20000, 4),
('28', 'Mercedes', 'Giallo', 1900, 'Manuale', 16000, 4),
('29', 'Fiat', 'Arancione', 1500, 'Manuale', 13000, 4),
('30', 'Honda', 'Viola', 1700, 'Automatico', 14000, 4),
('31', 'Ford', 'Nero', 1400, 'Manuale', 12500, 4),
('32', 'Mercedes', 'Blu', 1600, 'Automatico', 15500, 4),
('33', 'Fiat', 'Rosso', 1800, 'Manuale', 16500, 4),
('34', 'Honda', 'Grigio', 2000, 'Automatico', 18500, 4),
('35', 'Ford', 'Nero', 1900, 'Manuale', 17000, 4),
('36', 'Mercedes', 'Argento', 1500, 'Manuale', 13500, 4),
('37', 'Fiat', 'Arancione', 1300, 'Automatico', 12000, 4),
('38', 'Fiat', 'Viola', 1700, 'Manuale', 14500, 4),
('39', 'Fiat', 'Bianco', 1400, 'Automatico', 13000, 4),
('40', 'Honda', 'Nero', 2000, 'Manuale', 17500, 4),
('41', 'Fiat', 'Rosso', 1400, 'Manuale', 12000, 5),
('42', 'Honda', 'Blu', 2000, 'Automatico', 18000, 5),
('43', 'Ford', 'Nero', 1600, 'Manuale', 15000, 5),
('44', 'Fiat', 'Grigio', 1800, 'Automatico', 17000, 5),
('45', 'Honda', 'Verde', 1300, 'Manuale', 11000, 5),
('46', 'Ford', 'Bianco', 2500, 'Automatico', 22000, 5),
('47', 'Mercedes', 'Argento', 2200, 'Automatico', 20000, 5),
('48', 'Mercedes', 'Giallo', 1900, 'Manuale', 16000, 5),
('49', 'Fiat', 'Arancione', 1500, 'Manuale', 13000, 5),
('50', 'Honda', 'Viola', 1700, 'Automatico', 14000, 5),
('51', 'Ford', 'Nero', 1400, 'Manuale', 12500, 5),
('52', 'Mercedes', 'Blu', 1600, 'Automatico', 15500, 5),
('53', 'Fiat', 'Rosso', 1800, 'Manuale', 16500, 5),
('54', 'Honda', 'Grigio', 2000, 'Automatico', 18500, 5),
('55', 'Ford', 'Nero', 1900, 'Manuale', 17000, 5),
('56', 'Mercedes', 'Argento', 1500, 'Manuale', 13500, 5),
('57', 'Fiat', 'Arancione', 1300, 'Automatico', 12000, 5),
('58', 'Fiat', 'Viola', 1700, 'Manuale', 14500, 5),
('59', 'Fiat', 'Bianco', 1400, 'Automatico', 13000, 5),
('60', 'Honda', 'Nero', 2000, 'Manuale', 17500, 5),
('61', 'Honda', 'Blu', 2000, 'Automatico', 18000, 1),
('62', 'Ford', 'Nero', 1600, 'Manuale', 15000, 1),
('63', 'Fiat', 'Grigio', 1800, 'Automatico', 17000, 1),
('64', 'Honda', 'Verde', 1300, 'Manuale', 11000, 1),
('65', 'Ford', 'Bianco', 2500, 'Automatico', 22000, 1),
('66', 'Mercedes', 'Argento', 2200, 'Automatico', 20000, 1),
('67', 'Mercedes', 'Giallo', 1900, 'Manuale', 16000, 1),
('68', 'Fiat', 'Arancione', 1500, 'Manuale', 13000, 1),
('69', 'Honda', 'Viola', 1700, 'Automatico', 14000, 1),
('70', 'Ford', 'Nero', 1400, 'Manuale', 12500, 1),
('71', 'Mercedes', 'Blu', 1600, 'Automatico', 15500, 1),
('72', 'Fiat', 'Rosso', 1800, 'Manuale', 16500, 1),
('73', 'Honda', 'Grigio', 2000, 'Automatico', 18500, 1),
('74', 'Ford', 'Nero', 1900, 'Manuale', 17000, 1),
('75', 'Mercedes', 'Argento', 1500, 'Manuale', 13500, 1),
('76', 'Fiat', 'Arancione', 1300, 'Automatico', 12000, 1),
('77', 'Fiat', 'Viola', 1700, 'Manuale', 14500, 1),
('78', 'Fiat', 'Bianco', 1400, 'Automatico', 13000, 1),
('79', 'Honda', 'Nero', 2000, 'Manuale', 17500, 1),
('80', 'Fiat', 'Rosso', 1400, 'Manuale', 12000, 2),
('81', 'Honda', 'Blu', 2000, 'Automatico', 18000, 2),
('82', 'Ford', 'Nero', 1600, 'Manuale', 15000, 2),
('83', 'Fiat', 'Grigio', 1800, 'Automatico', 17000, 2),
('84', 'Honda', 'Verde', 1300, 'Manuale', 11000, 2),
('85', 'Ford', 'Bianco', 2500, 'Automatico', 22000, 2),
('86', 'Mercedes', 'Argento', 2200, 'Automatico', 20000, 2),
('87', 'Mercedes', 'Giallo', 1900, 'Manuale', 16000, 2),
('88', 'Fiat', 'Arancione', 1500, 'Manuale', 13000, 2),
('89', 'Honda', 'Viola', 1700, 'Automatico', 14000, 2),
('90', 'Ford', 'Nero', 1400, 'Manuale', 12500, 2),
('91', 'Mercedes', 'Blu', 1600, 'Automatico', 15500, 2),
('92', 'Fiat', 'Rosso', 1800, 'Manuale', 16500, 2),
('93', 'Honda', 'Grigio', 2000, 'Automatico', 18500, 2),
('94', 'Ford', 'Nero', 1900, 'Manuale', 17000, 2),
('95', 'Mercedes', 'Argento', 1500, 'Manuale', 13500, 2),
('96', 'Fiat', 'Arancione', 1300, 'Automatico', 12000, 2),
('97', 'Fiat', 'Viola', 1700, 'Manuale', 14500, 2),
('98', 'Fiat', 'Bianco', 1400, 'Automatico', 13000, 2),
('99', 'Honda', 'Nero', 2000, 'Manuale', 17500, 2);


-- Marca e Colore delle Auto di che costano più di 10.000 €
SELECT 
    auto.marca, auto.colore
FROM
    auto
WHERE
    prezzo > 10000;

-- Tutti i proprietari di un’auto di colore ROSSO
SELECT 
    *
FROM
    proprietari
         JOIN
    auto ON proprietari.targa = auto.targa
WHERE
    auto.colore = 'rosso';

-- Costo totale di tutte le auto con Cilindrata superiore a 1600lo c14
SELECT 
    SUM(auto.prezzo)
FROM
    auto
WHERE
    cilindrata > 1600;
    
   -- Targa e Nome del proprietario delle Auto in una concessionaria della Città di Roma
SELECT 
    auto.targa, proprietari.nominativo
FROM
    auto
        JOIN
    proprietari ON proprietari.targa = auto.targa
        JOIN
    concessionario ON concessionario.id_conc = auto.id_conc
WHERE
    concessionario.città = 'roma' ;

-- Per ogni Concessionaria, il numero di Auto
SELECT 
    concessionario.città, COUNT(*)
FROM
    auto
        JOIN
    concessionario ON concessionario.id_conc = auto.id_conc
GROUP BY concessionario.città;

-- Il Responsabile di Concessionaria di tutte le auto con Cambio Automatico e Anno Acquisto 2010
SELECT 
    concessionario.responsabile AS Responsabile
FROM
    concessionario
WHERE
    concessionario.id_conc IN (SELECT 
            auto.targa
        FROM
            auto
        WHERE
            auto.cambio = 'Automatico' IN (SELECT 
                    proprietari.targa
                FROM
                    proprietari
                WHERE
                    proprietari.anno_acq = 2010));
                    
 -- Per ciascuna TARGA il colore, il prezzo e la città in cui si trova il veicolo
SELECT 
    auto.targa, auto.colore, auto.prezzo, proprietari.città
FROM
    auto
        JOIN
    proprietari ON proprietari.targa = auto.targa;
    
 -- Le auto con almeno tre Proprietari
SELECT 
    targa
FROM
    proprietari
GROUP BY targa
HAVING COUNT(*) >= 3;

-- alternativa 
SELECT 
    auto.marca,
    proprietari.targa,
    COUNT(id_proprietario) AS n_proprietari
FROM
    auto
        JOIN
    proprietari ON auto.targa = proprietari.targa
GROUP BY proprietari.targa
HAVING n_proprietari >= 3;
-- La targa delle auto vendute nel 2015
SELECT 
    auto.targa
FROM
    auto
        JOIN
    proprietari ON auto.targa = proprietari.targa
WHERE
    anno_ven = '2015';

-- La regione con più auto (trovare un modo per associare la Regione)
SELECT regioni.regione, COUNT(*) AS numero_auto
FROM regioni 
JOIN auto  ON regioni.id_conc = auto.id_conc
GROUP BY regioni.regione
ORDER BY COUNT(*) DESC
LIMIT 1;

-- questo è quante auto per regione in base ai proprietari
SELECT 
    regioni.regione, COUNT(*)
FROM
    regioni
        JOIN
    concessionario ON regioni.id_conc = concessionario.id_conc
        JOIN
    proprietari ON proprietari.città = regioni.città
GROUP BY regioni.regione;


-- La Targa delle auto che si trovano a Milano, con cambio automatico, colore rosso, di proprietari residenti a Milano manca un dato ()
SELECT 
    auto.targa
FROM
    auto
        JOIN
    proprietari ON auto.targa = proprietari.targa
WHERE
    proprietari.città = 'Milano'
        AND auto.cambio = 'automatico'
        AND auto.colore = 'rosso';


-- 1. Gestione fatturato per Concessionaria
SELECT 
     auto.targa, sum(auto.prezzo)
FROM
    concessionario 
        JOIN
    auto ON auto.id_conc = concessionario.id_conc where auto.targa  in (select proprietari.targa from proprietari) 
    group by 1;


select distinct auto.targa from auto where auto.targa not in(select proprietari.targa from proprietari);

-- 2. Gestione Clienti per Concessionaria
SELECT 
    concessionario.id_conc, proprietari.nominativo
FROM
    concessionario
        JOIN
    auto ON concessionario.id_conc = auto.id_conc
        JOIN
    proprietari ON proprietari.targa = auto.targa
WHERE
    auto.targa IN (SELECT 
            auto.targa
        FROM
            auto
        WHERE
            auto.targa IN (SELECT 
                    proprietari.targa
                FROM
                    proprietari));
    
    

